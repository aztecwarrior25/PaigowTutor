//
//  HomeScreenViewController.h
//  PaiGow
//
//  Created by Shriniwas Kulkarni on 10/21/10.
//  Copyright 2010 ASU. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface HomeScreenViewController : UIViewController {

}

-(IBAction) onTrainTiles;
-(IBAction) onTrainTilePosition;
-(IBAction) onTrainHands;
-(IBAction) onTrainTileRanks; // this is for picking the greater tile
-(IBAction) onTrainHandRanks; // this is for picking the greater Hand
-(IBAction) onHelpAbout; // this is for CheatSheet
-(IBAction) onIntro; // this is intro

@end
