//
//  IntroViewController.h
//  PaiGow
//
//  Created by Shriniwas Kulkarni on 11/28/10.
//  Copyright 2010 ASU. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface IntroViewController : UIViewController {
	IBOutlet UIScrollView *myScrollView; // main view
	IBOutlet UIScrollView *myScrollView2; // app info view
	IBOutlet UIButton *homeButton;
	IBOutlet UIButton *infoButton;
	IBOutlet UIWebView *webView;
	bool isInfo;
}

@property (nonatomic, retain) UIScrollView *myScrollView;
@property (nonatomic, retain) UIScrollView *myScrollView2;
@property (nonatomic, retain) UIButton *homeButton;
@property (nonatomic, retain) UIButton *infoButton;
@property (nonatomic, retain) UIWebView *webView;

-(IBAction) onHelpAbout; // go to the tiles
-(IBAction) onInfo; // show Info
-(IBAction) onBack ;
@end
